


<?php $__env->startSection('title'); ?>
    Dashboard | Sniper
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Simple Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>Name</th>
                      <th>Trade</th>
                      <th>Trading panel </th>
                      <th>Open Closed Watch List</th>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sniper_project_1\resources\views/admin/dashboard1.blade.php ENDPATH**/ ?>